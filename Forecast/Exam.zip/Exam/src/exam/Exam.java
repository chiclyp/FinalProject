package exam;

import java.util.Scanner;

/**
 * Write a program that reads website addresses from the keyboard until stop is entered.
 * @author Pauline Chicoye
 */
public class Exam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Website site = new Website(null);
        Scanner scan = new Scanner(System.in);
        
        //Asking user their input
        System.out.println("Enter an URL or stop to exit");
        String web = scan.nextLine();
        
       //To keep track of counts of Commercial and Secure
        int comCount = 0;
        int secCount = 0;
        
        //The program will exit when read "stop"
        String exit = "stop";
        site.setAddress(web);
        
        while (!web.contentEquals(exit)){
            if (site.isCommercial() == true) {
                comCount++;
            }
            if (site.isSecure() == true) {
                secCount++;
            }
            System.out.println("Enter an URL or stop to exist");
            web = scan.nextLine();
        }
        
        System.out.println("#com =" + comCount);
        System.out.println("#sec =" + secCount);
        
        
    }
    
}
class  Website {
    private String address;

    public Website(String a) {
        a = address;
    }
    
    public void setAddress (String add) {
        this.address = add;
    }
    
    public String getAdd() {
        return address;
    }
    public boolean equals(Website copy){
        return address.equals(copy.address);
    }
    
    @Override
    public String toString(){
        return "The website address is : " + address;
    }
    
    public String address() {
        return address;
    }
    
    public boolean isCommercial(){
        String comEnd = ".com";
        return address.endsWith(comEnd);
    }
    
    public boolean isSecure() {
       String secStart = "https";
        return address.startsWith(secStart);
    }
    
}

